小T喝奶 1.3.0：首屏大字、快速记录，纵向上滑显示统计与设置。保留旧包名及本地存档键；升级请勿先卸载。滚动组件需 API Level 2。源码尚未通过 Vela 编译及真机验证。构建：npm install && npm run build。上传 ZIP 到原 GitHub 仓库根目录，保留原文件名触发 Actions。
